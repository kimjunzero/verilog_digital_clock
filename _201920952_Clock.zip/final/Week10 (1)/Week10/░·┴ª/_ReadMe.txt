#
# 황색등 점멸 기능이 추가된 사거리 교통신호등
#
# 사거리(N, E, S, W) 각 방향마다의 Green, Yellow, Red를 3개 LED로 표시함 
# [LED1~3]  : North의 G, Y, R      [LED6~8]   : East의 G, Y, R
# [LED9~11] : West의 G, Y, R       [LED14~16] : South의 G, Y, R
#
# Traffic_control Ver.4의 8개 state에 Blink state를 추가함
#
# state의 transition
#     Blink(1000)   <==>  (  N_Green(0000) --> N_Yellow(0001) --> E_Green(0010) --> E_Yellow(0011) -->  )   
#                         (  --> S_Green(0100) --> S_Yellow(0101) --> W_Green(0110) --> W_Yellow(0111)  )
#
#   상태유지시간(초)    Blink <0초>       Green <10초>     Yellow <3초>
#
# Reset 버튼 :   N_Green 상태로 귀환. 카운터를 0으로 초기화
#
# 버튼스위치 1 : 누를(key stroke) 때마다 toggle되며 황색등 점멸 상태로 전환됨. 
#               시계기능이 포함되면 새벽 특정시간대에 Blink 상태로 진입하도록 수정 가능.
#
