# 4초에 한번씩 S0 ~ S3의 4가지 상태를 천이하는 Moore FSM(Finite Sate Machine) 설계
#
# 입력클럭: 1 Hz
#	   4초에 한번 state transition을 하기 위해 div[1:0]를 이용하여 주파수 분주를 한다.(div[1]을 클럭으로 사용)
# reset 버튼 : 초기화
# x 입력: Bus switch 1
         0이면 S0-->S3, 1이면 S3-->S0 순으로 state transition을 한다.
# led_out[15:0] : 16개의 led중에서 4개씩 돌아가면서 켠다.
# seg_dat[6:0] : FND에 4초가 경과되는 것을 표시한다.
 