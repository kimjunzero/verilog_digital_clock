#
# Moore_FSM_Count에서 사용된 Function을 Task 사용하여 다시 구성
#