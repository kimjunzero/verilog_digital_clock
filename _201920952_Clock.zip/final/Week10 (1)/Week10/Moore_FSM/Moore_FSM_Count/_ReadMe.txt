#
# S0 ~ S3의 4가지 상태를 천이하는 Moore FSM(Finite Sate Machine) 설계
# 각 상태마다 머무는 시간이 상이: S0->3초, S1->4초, S2->6초, S3->8초
# 입력클럭: 1 Hz
#	   
# reset 버튼 : 초기화
# x 입력: Bus switch 1
         0이면 S0-->S3순으로, 1이면 역순(S3-->S0)으로 state transition을 한다.
# led_out[1:0] : 현재의 상태값(00, 01, 10, 11)을 led1, led2에 표시
# seg_dat[6:0] : 현재 상태의 머무는 시간(초수)을 FND에 표시한다.
#