#
# 간단한 사거리 교통신호등
#
# 사거리(N, E, S, W) 각 방향마다의 Green, Yellow, Red를 3개 LED로 표시함 
# LED1~3 : North의 G, Y, R         LED6~8 : East의 G, Y, R
# LED9~11 : West의 G, Y, R      LED14~16 : South의 G, Y, R
#
# state의 transition
#    N_Green(000) --> N_Yellow(001) --> E_Green(010) --> E_Yellow(011) --> S_Green(100) --> S_Yellow(101)
#    --> W_Green(110) --> W_Yellow(111)
#
#   상태유지시간(초)    Green <10초>     Yellow <3초>
#
# Reset 버튼: N_Green 상태로 귀환. 카운터를 0으로 초기화
#
